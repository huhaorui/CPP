#include <iostream>
using namespace std;
class Student
{
public:
	const Student(int n, float s) :num(n), score(s) {}
	const void change(int n, float s)
	{
		num = n;
		score = s;
	}
	const void display()
	{
		cout << num << " " << score << endl;
	}
public:
	int num;
	float score;
};
int main()
{
	const Student stud(101, 78.5);
	stud.display();
	stud.change(101, 80.5);
	stud.display();
	return 0;
}