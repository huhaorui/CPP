#pragma once
#include "date_time.h"
void pause();
void cls ();
date today();
bool is_proper_num(char c);
bool is_proper_num(string s);
int to_int(string s);
double to_double(string s);
date_time now();
string toString(int n);
string toString(double n);