#pragma once
#include <iostream>
class arraymax
{
private:
	int num[10];
public:
	int getmax();
	arraymax(int n[]);
	~arraymax();
};

